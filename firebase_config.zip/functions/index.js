const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.sendNotification = functions.firestore
  .document("messages/{chatId}/messages/{messageId}")
  .onCreate(async (snap, context) => {
    const message = snap.data();
    const payload = {
      notification: {
        title: "رسالة جديدة من " + message.senderName,
        body: message.text || "📩 رسالة جديدة",
      },
      token: message.receiverToken,
    };
    await admin.messaging().send(payload);
  });